function displayGame() {
  stroke(255); strokeWeight(3); line(0, groundY, width, groundY); noStroke();
  handleSpawner();
  handleMedkits();
  handleEnemies();
  updatePlayerLogic();
  drawUI();
  updateParticles();
  if (hp <= 0) { hp = 0; gameState = "GAMEOVER"; }
}

function handleSpawner() {
  if (!isBossSpawned) {
    let total = killsCount + enemies.length;
    if (total < 19 && enemies.length < 2) spawnEnemy(random() > 0.7 ? "BIG" : "NORMAL");
    else if (killsCount >= 19 && enemies.length === 0) { isBossSpawned = true; spawnEnemy("BOSS"); }
  }
}

function spawnEnemy(type = "NORMAL") {
  let startX = (random() > 0.5 ? -150 : width + 150);
  let e = { x: startX, isBoss: type === "BOSS", isBig: type === "BIG", hasHit: false };
  if (e.isBoss) { e.size = 180; e.hp = 10; e.maxHp = 10; e.speed = 1.1; e.dmg = 4; e.col = color(10); }
  else if (e.isBig) { e.size = 85; e.hp = 3; e.maxHp = 3; e.speed = 1.8; e.dmg = 1.5; e.col = color(120, 30, 30); }
  else { e.size = 55; e.hp = 1; e.maxHp = 1; e.speed = 2.5 + (killsCount/10); e.dmg = 1; e.col = color(255, 30, 30); }
  enemies.push(e);
}

function handleEnemies() {
  for (let i = enemies.length - 1; i >= 0; i--) {
    let e = enemies[i];
    let eY = groundY - e.size;
    if (e.x < x) e.x += e.speed; else e.x -= e.speed;
    
    fill(e.col); rect(e.x, eY, e.size, e.size); 
    push();
    fill(255); textSize(16); textAlign(CENTER); textStyle(BOLD);
    text(ceil(e.hp), e.x + e.size/2, eY - 25); 
    fill(50); rect(e.x, eY - 20, e.size, 8); 
    fill(e.isBoss ? "#FF00FF" : (e.hp > 1 ? "#FFD700" : "#00FF00")); 
    rect(e.x, eY - 20, map(e.hp, 0, e.maxHp, 0, e.size), 8); 
    pop();

    // Player Kena Hit (Getar Kuat)
    if (dist(x + 25, y + 25, e.x + e.size/2, eY + e.size/2) < (e.size/2 + 25)) {
      hp -= (e.dmg / 5); 
      shakeAmount = 5; // Getar layar pas kena damage
      fill(255, 0, 0, 40); rect(0, 0, width, height);
    }

    // Serangan Player (Getar Kecil)
    if (isAttacking && !e.hasHit) {
      let swordX = (arah === 1) ? x + 50 : x - 60;
      if (dist(swordX + 30, y + 25, e.x + e.size/2, eY + e.size/2) < (e.size/2 + 55)) {
        e.hp--; e.hasHit = true;
        shakeAmount = 3; // Getar layar pas nebas musuh
        createExplosion(e.x + e.size/2, eY + e.size/2, e.col); 
        if (e.hp <= 0) {
          if (!e.isBoss) {
            killsCount++;
            if (random() < 0.25) medkits.push({ x: e.x, y: eY });
          } else { bossKilled = 1; gameState = "WIN"; }
          enemies.splice(i, 1);
        }
      }
    }
  }
}

function handleMedkits() {
  for (let i = medkits.length - 1; i >= 0; i--) {
    let m = medkits[i];
    fill(0, 255, 0); rect(m.x, m.y, 25, 25);
    fill(255); rect(m.x + 10, m.y + 5, 5, 15); rect(m.x + 5, m.y + 10, 15, 5);
    if (m.y < groundY - 25) m.y += 3;
    if (dist(x + 25, y + 25, m.x + 12, m.y + 12) < 40) {
      hp = min(maxHp, hp + 20); medkits.splice(i, 1);
    }
  }
}

function drawUI() {
  push();
  noStroke(); fill(60); rect(20, 20, 180, 25);
  ellipse(20, 32.5, 25, 25); ellipse(200, 32.5, 25, 25);
  fill(255, 0, 0);
  let w = map(hp, 0, maxHp, 0, 180);
  rect(20, 20, w, 25); ellipse(20, 32.5, 25, 25);
  if(w > 0) ellipse(20 + w, 32.5, 25, 25);
  fill(255); textSize(18); textStyle(BOLD); text("HP: " + ceil(hp), 225, 38); 
  textSize(16); textStyle(NORMAL);
  text("ENEMIES: " + killsCount + "/19", 20, 75);
  text("BOSS: " + bossKilled + "/1", 20, 100); 
  if(isBossSpawned && bossKilled === 0) { fill(255, 0, 0); textStyle(BOLD); text("BOSS FIGHT!", 20, 125); }
  pop();
}

function displayMenu() {
  push(); textAlign(CENTER, CENTER); textStyle(BOLDITALIC); stroke(255, 0, 0); strokeWeight(5); fill(255);
  textSize(width / 12); text("SQUARE SLAYER", width / 2, height / 2 - 50);
  noStroke(); fill(255, 0, 0); ellipse(width/2, height/2 + 80, 85, 85);
  fill(255); triangle(width/2 - 15, height/2 + 65, width/2 - 15, height/2 + 95, width/2 + 25, height/2 + 80);
  textSize(25); textStyle(BOLD); text("PRESS SPACE TO PLAY", width/2, height/2 + 160); pop();
}

function createExplosion(ex, ey, col) {
  for (let i = 0; i < 15; i++) {
    particles.push({ x: ex, y: ey, vx: random(-7, 7), vy: random(-7, 7), life: 255, c: color(random(150, 255), 0, 0) });
  }
}

function updateParticles() {
  for (let i = particles.length - 1; i >= 0; i--) {
    let p = particles[i]; p.x += p.vx; p.y += p.vy; p.life -= 8;
    fill(red(p.c), green(p.c), blue(p.c), p.life); noStroke(); ellipse(p.x, p.y, random(4, 7), random(4, 7));
    if (p.life <= 0) particles.splice(i, 1);
  }
}

function displayPause() { push(); fill(0, 150); rect(0, 0, width, height); fill(255); textAlign(CENTER); textSize(50); text("PAUSED", width/2, height/2); pop(); }
function displayGameOver() { push(); background(50, 0, 0); fill(255); textAlign(CENTER); textSize(50); text("GAME OVER", width/2, height/2); textSize(20); text("Press R to Restart", width/2, height/2 + 50); pop(); }
function displayWin() { push(); background(0, 50, 0); fill(255); textAlign(CENTER); textSize(50); text("VICTORY!", width/2, height/2); textSize(20); text("Press R to Restart", width/2, height/2 + 50); pop(); }