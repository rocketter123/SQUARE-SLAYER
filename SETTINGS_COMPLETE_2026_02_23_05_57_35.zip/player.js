function updatePlayerLogic() {
  // Gerak horizontal
  checkKeyboardMovement(); 

  // Dash
  if (isDashing) {
    x += (arah * 18); 
    fill(255, 100); rect(x - (arah*10), y, 50, 50);
    dashTimer--; if (dashTimer <= 0) isDashing = false;
  }

  // Lompat & Gravitasi
  y += yVelocity;
  if (y < groundY - 50) { 
    yVelocity += gravity; jumping = true; 
  } else { 
    yVelocity = 0; y = groundY - 50; jumping = false; 
  }
  x = constrain(x, 0, width - 50);

  // Gambar Karakter
  fill(255); rect(x, y, 50, 50);

  // Gambar Pedang & Logika Serang
  if (isAttacking) {
    fill(255, 0, 0); 
    let swordX = (arah === 1) ? x + 50 : x - 60;
    rect(swordX, y + 20, 60, 15);
    attackTimer--; 
    if (attackTimer <= 0) {
      isAttacking = false;
      for(let en of enemies) en.hasHit = false;
    }
  }
}

function attackAction() { 
  if(!isAttacking){ 
    isAttacking = true; 
    attackTimer = 12; 
    for(let en of enemies) en.hasHit = false;
  } 
}
function dashAction() { isDashing = true; dashTimer = 10; }