let x, y, yVelocity = 0, gravity = 0.7;
let moveSpeed = 7, jumping = false;
let isAttacking = false, attackTimer = 0, arah = 1;
let hp = 100, maxHp = 100;
let isDashing = false, dashTimer = 0;
let enemies = [], medkits = [], particles = [];
let killsCount = 0, bossKilled = 0, isBossSpawned = false;
let gameState = "START", groundY;

// Variabel Screen Shake
let shakeAmount = 0;

function setup() {
  document.body.style.overflow = "hidden";
  document.body.style.margin = "0";
  createCanvas(windowWidth, windowHeight);
  groundY = height - 110;
  resetGamePositions();
}

function draw() {
  background(0);
  
  // Efek Getar Layar
  if (shakeAmount > 0) {
    translate(random(-shakeAmount, shakeAmount), random(-shakeAmount, shakeAmount));
    shakeAmount *= 0.9; // Getaran perlahan menghilang
    if (shakeAmount < 0.1) shakeAmount = 0;
  }

  if (gameState === "START") displayMenu();
  else if (gameState === "PLAY") displayGame();
  else if (gameState === "PAUSE") displayPause();
  else if (gameState === "GAMEOVER") displayGameOver();
  else if (gameState === "WIN") displayWin();
}

function resetGamePositions() { 
  x = width/2; y = groundY-50; hp = 100; killsCount = 0; bossKilled = 0;
  enemies = []; medkits = []; isBossSpawned = false; particles = []; 
  shakeAmount = 0;
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  groundY = height - 110;
}