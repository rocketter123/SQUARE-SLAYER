// Variable bantuan untuk mencegah input berulang (debounce)
let lastButtonState = {};

function draw() {
  // Panggil fungsi input setiap frame
  pollGamepadButtons();
  checkKeyboardMovement();
  
  // Logika game Anda di bawah sini...
}

function checkKeyboardMovement() {
  if (gameState === "PLAY") {
    // 1. Keyboard & Remote TV D-Pad
    if (keyIsDown(LEFT_ARROW)) { x -= moveSpeed; arah = -1; }
    if (keyIsDown(RIGHT_ARROW)) { x += moveSpeed; arah = 1; }

    // 2. Gamepad Analog & D-Pad
    let pads = navigator.getGamepads();
    if (pads[0]) {
      let gp = pads[0];
      // Analog Stick Kiri (< -0.5) atau D-Pad Left (button 14)
      if (gp.axes[0] < -0.5 || (gp.buttons[14] && gp.buttons[14].pressed)) { 
        x -= moveSpeed; arah = -1; 
      }
      // Analog Stick Kanan (> 0.5) atau D-Pad Right (button 15)
      if (gp.axes[0] > 0.5 || (gp.buttons[15] && gp.buttons[15].pressed)) { 
        x += moveSpeed; arah = 1; 
      }
    }
  }
}

function pollGamepadButtons() {
  let pads = navigator.getGamepads();
  if (!pads[0]) return;
  let gp = pads[0];

  // Helper untuk deteksi klik tunggal (bukan tahan)
  const isPressed = (idx) => gp.buttons[idx] && gp.buttons[idx].pressed;
  const justPressed = (idx) => {
    if (isPressed(idx) && !lastButtonState[idx]) {
      lastButtonState[idx] = true;
      return true;
    } else if (!isPressed(idx)) {
      lastButtonState[idx] = false;
    }
    return false;
  };

  // Mapping Tombol: 0=A, 1=B, 2=X, 3=Y, 8=Select, 9=Start
  if (gameState === "START") {
    if (justPressed(0) || justPressed(9)) gameState = "PLAY"; // A atau Start
  } 
  else if (gameState === "PLAY") {
    if (justPressed(0)) { if (!jumping) yVelocity = -14; } // A = Jump
    if (justPressed(2)) attackAction();                    // X = Attack
    if (justPressed(3)) dashAction();                      // Y = Dash
    if (justPressed(1) || justPressed(9)) gameState = "PAUSE"; // B atau Start = Pause
  }
  else if (gameState === "PAUSE") {
    if (justPressed(1) || justPressed(9)) gameState = "PLAY"; // Resume
    if (justPressed(8)) { resetGamePositions(); gameState = "START"; } // Select = Reset ke Menu
  }
  else if (gameState === "GAMEOVER" || gameState === "WIN") {
    if (justPressed(0) || justPressed(8)) { // A atau Select = Restart
      resetGamePositions();
      gameState = "PLAY";
    }
  }
}

function keyPressed() {
  // Dukungan Keyboard & Tombol Back Remote TV
  if (gameState === "START") {
    if (keyCode === 32 || keyCode === ENTER) gameState = "PLAY";
  } 
  else if (gameState === "PLAY") {
    if (keyCode === 32) { if (!jumping) yVelocity = -14; } 
    if (key === 'x' || key === 'X') attackAction();
    if (key === 'z' || key === 'Z') dashAction();
    // 27 = ESC, 4 = Android Back Button
    if (key === 'p' || key === 'P' || keyCode === 27 || keyCode === 4) gameState = "PAUSE";
  } 
  else if (gameState === "PAUSE") {
    if (key === 'p' || key === 'P' || keyCode === 27 || keyCode === 4) gameState = "PLAY";
    if (key === 's' || key === 'S') { resetGamePositions(); gameState = "START"; } // Select/S
  }
  else if (gameState === "GAMEOVER" || gameState === "WIN") {
    if (key === 'r' || key === 'R' || keyCode === ENTER) {
      resetGamePositions();
      gameState = "PLAY";
    }
  }
  return false; // Mencegah scrolling browser saat tekan panah
}