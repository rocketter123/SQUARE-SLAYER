function checkKeyboardMovement() {
  if (gameState === "PLAY") {
    if (keyIsDown(LEFT_ARROW)) { x -= moveSpeed; arah = -1; }
    if (keyIsDown(RIGHT_ARROW)) { x += moveSpeed; arah = 1; }
  }
}

function keyPressed() {
  if (gameState === "START") {
    if (keyCode === 32 || keyCode === ENTER) gameState = "PLAY";
  } 
  else if (gameState === "PLAY") {
    if (keyCode === 32) { if (!jumping) yVelocity = -14; } 
    if (key === 'x' || key === 'X') attackAction();
    if (key === 'z' || key === 'Z') dashAction();
    if (key === 'p' || key === 'P') gameState = "PAUSE";
  } 
  else if (gameState === "PAUSE") {
    if (key === 'p' || key === 'P') gameState = "PLAY";
  }
  else if (gameState === "GAMEOVER" || gameState === "WIN") {
    if (key === 'r' || key === 'R') {
      resetGamePositions();
      gameState = "PLAY";
    }
  }
}